module.exports = {
    weekEnd: 6,
    secretKey: 'lemarchnadisecretauth',
    session_expiry: 30,
    api_authentication: false,
    token_expiresIn: { expiresIn: 3000 }
}   